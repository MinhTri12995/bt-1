const form = document.getElementById('lunar-form');
const result = document.getElementById('result');
const can = ['Canh', 'Tân', 'Nhâm', 'Quý', 'Giáp', 'Ất', 'Bính', 'Đinh', 'Mậu', 'Kỷ'];
const chi = ['Thân', 'Dậu', 'Tuất', 'Hợi', 'Tý', 'Sửu', 'Dần', 'Mão', 'Thìn', 'Tỵ', 'Ngọ', 'Mùi'];

form.addEventListener('submit', (event) => {
  event.preventDefault();
  const year = Number(document.getElementById('year').value);
  if (!Number.isSafeInteger(year) || year <= 0) {
    result.textContent = 'Vui lòng nhập một năm nguyên dương hợp lệ.';
    result.classList.add('error');
    return;
  }
  result.classList.remove('error');
  result.textContent = `Năm ${year} là năm ${can[year % 10]} ${chi[year % 12]}.`;
});
form.requestSubmit();
