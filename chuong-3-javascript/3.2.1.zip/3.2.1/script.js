const hoverBox = document.getElementById('hover-box');
const hoverImage = document.getElementById('hover-image');
const dateButton = document.getElementById('date-button');
const dateResult = document.getElementById('date-result');
const uppercaseInput = document.getElementById('uppercase-input');

const enterBox = () => { hoverBox.textContent = 'Mouse Event'; };
const leaveBox = () => { hoverBox.textContent = 'Hover Me'; };
hoverBox.addEventListener('mouseenter', enterBox);
hoverBox.addEventListener('mouseleave', leaveBox);
hoverBox.addEventListener('focus', enterBox);
hoverBox.addEventListener('blur', leaveBox);

hoverImage.addEventListener('mouseenter', () => {
  hoverImage.style.width = '176px';
  hoverImage.style.height = '132px';
});
hoverImage.addEventListener('mouseleave', () => {
  hoverImage.style.width = '160px';
  hoverImage.style.height = '120px';
});

dateButton.addEventListener('click', () => {
  dateResult.textContent = new Date().toLocaleString('vi-VN', { dateStyle: 'full', timeStyle: 'medium' });
});

uppercaseInput.addEventListener('input', () => {
  const cursorStart = uppercaseInput.selectionStart;
  const cursorEnd = uppercaseInput.selectionEnd;
  uppercaseInput.value = uppercaseInput.value.toLocaleUpperCase('vi-VN');
  uppercaseInput.setSelectionRange(cursorStart, cursorEnd);
});
