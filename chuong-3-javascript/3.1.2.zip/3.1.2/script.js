const form = document.getElementById('leap-form');
const result = document.getElementById('result');

form.addEventListener('submit', (event) => {
  event.preventDefault();
  const year = Number(document.getElementById('year').value);
  if (!Number.isSafeInteger(year) || year <= 0) {
    result.textContent = 'Vui lòng nhập một năm nguyên dương hợp lệ.';
    result.classList.add('error');
    return;
  }
  result.classList.remove('error');
  const isLeapYear = year % 400 === 0 || (year % 4 === 0 && year % 100 !== 0);
  result.textContent = `${year}: ${isLeapYear ? 'năm nhuận' : 'năm không nhuận'}`;
});
form.requestSubmit();
