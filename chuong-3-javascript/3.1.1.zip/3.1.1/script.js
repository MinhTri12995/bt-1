const form = document.getElementById('interest-form');
const result = document.getElementById('result');
const format = (number) => new Intl.NumberFormat('vi-VN', { maximumFractionDigits: 4 }).format(number);

form.addEventListener('submit', (event) => {
  event.preventDefault();
  const principal = Number(document.getElementById('principal').value);
  const rate = Number(document.getElementById('rate').value);
  const years = Number(document.getElementById('years').value);

  if (![principal, rate, years].every(Number.isFinite) || principal < 0 || rate < 0 || !Number.isInteger(years) || years < 0) {
    result.textContent = 'Vui lòng nhập số tiền và lãi suất không âm, số năm là số nguyên không âm.';
    result.classList.add('error');
    return;
  }

  result.classList.remove('error');
  const annualInterest = principal * rate / 100;
  const totalInterest = annualInterest * years;
  const total = principal + totalInterest;
  result.replaceChildren();
  const lines = [
    `Tiền lãi mỗi năm: ${format(annualInterest)} triệu đồng`,
    `Tổng tiền lãi sau ${years} năm: ${format(totalInterest)} triệu đồng`,
    `Tổng số tiền phải trả: ${format(total)} triệu đồng`
  ];
  for (const line of lines) {
    const paragraph = document.createElement('p');
    paragraph.textContent = line;
    result.appendChild(paragraph);
  }
});
form.requestSubmit();
