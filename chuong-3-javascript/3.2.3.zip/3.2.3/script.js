const form = document.getElementById('month-form');
const result = document.getElementById('result');

form.addEventListener('submit', (event) => {
  event.preventDefault();
  const month = Number(document.getElementById('month').value);
  const year = Number(document.getElementById('year').value);

  if (!Number.isSafeInteger(year) || year <= 0 || !Number.isInteger(month) || month < 1 || month > 12) {
    result.textContent = 'Vui lòng nhập năm nguyên dương và chọn tháng hợp lệ.';
    result.classList.add('error');
    return;
  }

  result.classList.remove('error');
  const isLeapYear = year % 400 === 0 || (year % 4 === 0 && year % 100 !== 0);
  const days = [31, isLeapYear ? 29 : 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
  result.textContent = `Tháng ${month} năm ${year} có ${days[month - 1]} ngày.`;
});
form.requestSubmit();
