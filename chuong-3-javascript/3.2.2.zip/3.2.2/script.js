const form = document.getElementById('fruit-form');
const result = document.getElementById('result');
const normalize = (value) => value.trim().toLocaleLowerCase('vi-VN').normalize('NFD').replace(/[\u0300-\u036f]/g, '').replace(/đ/g, 'd').replace(/\s+/g, ' ');
const prices = new Map([
  ['oi', 20000],
  ['dua hau', 20000],
  ['tao', 30000],
  ['cam', 40000],
  ['chom chom', 40000],
  ['mang cut', 50000]
]);

form.addEventListener('submit', (event) => {
  event.preventDefault();
  const name = normalize(document.getElementById('ten_hoa_qua').value);
  result.classList.remove('error');
  if (prices.has(name)) {
    result.textContent = `${new Intl.NumberFormat('vi-VN').format(prices.get(name))} VND/kg`;
  } else {
    result.textContent = 'Không thấy';
  }
});
form.requestSubmit();
