BÀI 3 — FLOAT VÀ CLEAR (mục 2.1.7, trang 31-33)
Mở file float-clear.html bằng trình duyệt.
float-clear.css dùng các class .left, .right, .center đúng theo đoạn mã trang 33.
Phần .clearfix dùng clear: both để nội dung phía sau không tràn lên khối nổi.
Khi màn hình hẹp, ba khối xếp dọc để không tràn khung trình duyệt.
