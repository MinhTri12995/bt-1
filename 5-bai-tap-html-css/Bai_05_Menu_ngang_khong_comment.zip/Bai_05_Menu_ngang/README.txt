BÀI 5 — MENU NGANG MỘT CẤP (mục 2.3.1, trang 36-37)
Mở file menu.html bằng trình duyệt.
- menu.html chứa h1 và danh sách 7 mục từ "Trang chủ" đến "Liên hệ".
- menu.css chứa .menu, float:left, kiểu chữ và hiệu ứng hover.
- Nhấn chọn một mục để đánh dấu mục đang chọn.
Không cần Internet.
