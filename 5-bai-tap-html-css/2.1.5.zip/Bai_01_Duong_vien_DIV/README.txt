BÀI 1 — CÁC KIỂU ĐỊNH DẠNG ĐƯỜNG VIỀN (mục 2.1.5, trang 30-31)
Mở file rectangles.html bằng Chrome, Edge hoặc Firefox.
rectangles.css chứa các định dạng của 3 thẻ div lồng nhau:
- Outside: viền xanh dương nét chấm, bo góc, khoảng đệm.
- Middle: viền đỏ nét đứt, bo góc, khoảng đệm.
- Inner: viền xanh lá nét liền, bo góc, khoảng đệm, căn chữ giữa và đặt cỡ chữ.
Dùng &lt; và &gt; để hiện ký tự < và >.
Không cần mạng Internet hoặc cài đặt thư viện.
