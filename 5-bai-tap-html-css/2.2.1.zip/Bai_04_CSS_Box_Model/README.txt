BÀI 4 — CSS BOX MODEL / GIAO DIỆN DANH SÁCH SẢN PHẨM (trang 33-35)
Mở file products.html bằng trình duyệt.
Tài nguyên trong ZIP:
- products.html: giao diện danh sách 8 sản phẩm mỗi trang.
- products.css: các class .hh-box, .hh-box-name, .hh-box-image, .hh-box-price, .hh-box-actions, .hh-box-icon.
- products.js: nút First / Previous / Next / Last và chức năng minh họa các nút biểu tượng.
- images/: các ảnh SVG được dựng sẵn (minh họa máy ảnh, NEW, ngôi sao, phong bì, giỏ).
Ảnh máy ảnh là vector minh họa thay cho ảnh chụp gốc của giáo trình.
KHÔNG di chuyển các file HTML, CSS, JS ra khỏi thư mục của bài nếu chưa sửa đường dẫn.
