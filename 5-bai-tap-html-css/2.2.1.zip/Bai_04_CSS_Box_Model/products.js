const pages = Array.from(document.querySelectorAll('.product-page'));
const status = document.getElementById('status');
let currentPage = 0;
let cartCount = 0;

function showPage(index) {
  currentPage = Math.max(0, Math.min(index, pages.length - 1));
  pages.forEach((page, i) => { page.hidden = i !== currentPage; });
  document.querySelector('[data-go="first"]').disabled = currentPage === 0;
  document.querySelector('[data-go="previous"]').disabled = currentPage === 0;
  document.querySelector('[data-go="next"]').disabled = currentPage === pages.length - 1;
  document.querySelector('[data-go="last"]').disabled = currentPage === pages.length - 1;
  status.textContent = `Trang ${currentPage + 1} / ${pages.length}`;
}

document.querySelector('.pagination').addEventListener('click', (event) => {
  const button = event.target.closest('[data-go]');
  if (!button) return;
  const targets = {
    first: 0, previous: currentPage - 1,
    next: currentPage + 1, last: pages.length - 1
  };
  showPage(targets[button.dataset.go]);
});

document.querySelector('.product-list').addEventListener('click', (event) => {
  const button = event.target.closest('[data-action]');
  if (!button) return;
  const name = button.closest('.hh-box').querySelector('.hh-box-name').textContent;
  switch (button.dataset.action) {
    case 'favourite': {
      const active = button.getAttribute('aria-pressed') !== 'true';
      button.setAttribute('aria-pressed', String(active));
      status.textContent = active ? `Đã thích ${name}` : `Đã bỏ thích ${name}`;
      break;
    }
    case 'basket':
      status.textContent = `Đã thêm ${name} vào giỏ (${++cartCount} sản phẩm)`;
      break;
    case 'letter':
      status.textContent = `Bạn vừa chọn liên hệ về ${name}`;
      break;
  }
});

showPage(0);
