BÀI 2 — ĐỊNH DẠNG HỖN HỢP (mục 2.1.6, trang 31)
Mở file languages.html bằng trình duyệt.
HTML dùng các thẻ <span class="lang"> cho PHP, JavaScript, C# và Java.
File langs.css là CSS được nhúng bằng <link rel="stylesheet" href="langs.css">.
Lưu ý: Sửa cú pháp viền trong gợi ý sách thành "border: 1px solid #AAA" để viền hiện đúng.
Không cần Internet.
